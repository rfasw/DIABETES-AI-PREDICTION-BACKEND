from tensorflow.keras.models import load_model
import joblib
import numpy as np

# Load components
model = load_model('diabetes_model.keras')
scaler = joblib.load('scaler.save')

def predict_diabetes(age, bloodsugar, systolicBp, diastolicBp):
    # Prepare input
    new_data = np.array([[age, bloodsugar, systolicBp, diastolicBp]])
    scaled_data = scaler.transform(new_data)
    
    # Make prediction
    prediction = model.predict(scaled_data)
    proba = prediction[0][0]
    result = 'Diabetic' if proba > 0.5 else 'Not Diabetic'
    
    return {
        'probability': float(proba),
        'result': result
    }

# Example usage
if __name__ == "__main__":
    test_case = predict_diabetes(50, 120, 130, 80)
    print(f"Prediction: {test_case['result']}")
    print(f"Probability: {test_case['probability']:.4f}")